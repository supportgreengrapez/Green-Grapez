<?php
namespace App\Http\Controllers;
use Redirect;
use Illuminate\Http\Request;
use Auth;
use DB;
use Table;
use DateTime;
use App\product;
use App\order;
use App\order_ui_report;
use App\order_ios_report;
use App\order_android_report;
use App\order_web_report;
use App\User;
use App\developer;
use App\custom_link;
use App\project_assignment;
use App\task;
use App\tasklist;
use App\blogpost;
use App\enquire;
use Carbon\Carbon;
use Mail;
use Response;
class adminController extends Controller
{

    public function add_additional_requirements_view($id)
    {
        $tabs = DB::select("select requirment_for from additional_requirements where order_id = '$id' and status = 0");
        $result = DB::select("select DISTINCT header from additional_requirements where order_id = '$id'");
        return view('admin.add_requirements', compact('id', 'result', 'tabs'));
    }

    public function add_additional_requirements(Request $request, $id)
    {

        $req = $request->input('mytexttt');

        $tok = strtok($req[2], "\n");

        $tok = strtok($req[2], "\n");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok("\n");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }
        array_pop($array);

        foreach ($array as $reqsss)
        {
            $reqsss = trim(preg_replace('/\s+/', ' ', $reqsss));

            DB::insert("insert into additional_requirements (order_id,requirment_for,header,additional_requirements,created_at) values (?,?,?,?,?)", array(
                $id,
                $req[0],
                $req[1],
                $reqsss,
                NOW()
            ));
        }

        //          $total = count($str);
        //           if(count($str)>0)
        //           {
        //           for($i = 0; $i< $total ; $i = $i+2)
        //           {
        //                 $tok = strtok($str[$i+1], "\n");
        //     $skillset =$tok;
        //   $array = array_wrap($skillset);
        //     while ($tok !== false) {
        //         $tok = strtok("\n");
        //       if(is_string($tok))
        //       $skillset= $tok;
        //      //  $array = array_prepend($array, $skillset);
        //      array_push($array, $skillset);
        //     }
        //   array_pop($array);
        //  foreach($array as $req)
        //  {
        //      $req = trim(preg_replace('/\s+/', ' ', $req));
        //              DB::insert("insert into additional_requirements (order_id,header,additional_requirements,created_at) values (?,?,?,?)",array($id,$str[$i],$req,NOW()));
        //  }
        //      }
        //           }
        return redirect("/admin/view/order/active/" . $id);
        //  return redirect()->back()->with('message','You have Successfully added addition requirement, Please wait our Customer Support will review and confirm you by call or email');
        
    }
    public function detail_enquiry($id)
    {
        $order = db::select("select users.*,enquires.* from users,enquires where enquires.user_id = users.id and enquires.id ='$id'");

        return view('admin.detail_enquiry', compact('order'));
    }
    public function enquiry_list()
    {
        $order = db::select("select* from users,enquires where enquires.user_id = users.id");
        return view("admin.enquiry_list", compact('order'));
    }
    public function delete_blog_post($id)
    {
        blogpost::find($id)->delete();

        return redirect('admin-blog');
    }
    public function edit_blog_view($id)
    {

        $p = blogpost::find($id);

        $page_name = "edit blog post";
        return view('admin.edit_blog', compact('p', 'page_name'));
    }
    public function edit_blog(Request $request, $id)
    {
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $blogpost = blogpost::find($id);
        if (!empty($thumbnail)) $blogpost->image = $thumbnail;
        $blogpost->body = $request->input('body');
        $blogpost->title = $request->input('title');

        $blogpost->save();

        return redirect('admin-blog');
    }
    public function create_blog_post(Request $request)
    {
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        $blogpost = new blogpost();
        $blogpost->image = $thumbnail;
        $blogpost->body = $request->input('body');
        $blogpost->title = $request->input('title');

        $blogpost->save();

        return redirect('admin-blog');
    }
    public function bloglist()
    {
        $result = blogpost::all();
        $page_name = "Blog Posts";
        return view('admin.bloglist', compact('result', 'page_name'));
    }
    public function create_blog_post_view()
    {
        $page_name = "Create Blog Posts";
        return view('admin.create_post', compact('page_name'));
    }

    public function live_chat_view()
    {
        $user = db::select("Select users.*, (Select message from chats where chats.user_from = '1' and user_to=users.id  or (user_to='1' and user_from=users.id) order by chats.id desc limit 1) as lastmessage from users");
        return view('admin.live_chat', compact('user'));
    }
    public function home_view()
    {

        return view('admin.home');

    }
    public function login_view()
    {

        return view('admin.login');

    }

    public function login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $userdata = array(
            'username' => $username,
            'password' => $password
        );

        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $password = md5($request->input('password'));

        $result = DB::select("select* from admin_details where username = '$username' and password='$password' ");
        if (count($result) > 0)
        {

            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('type', 'admin');
            $request->session()
                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
            session()
                ->put('admin_id', $result[0]->{'pk_id'});
            /*
            defining permission in session
            */

            return Redirect::to('admin/home');
        }
        else
        {

            return view('admin.login')
                ->withErrors('username or password incorrect');
        }

    }
    public function check()
    {
        $auth = Auth::guard('admin');
        return dd($auth->user());

        return bcrypt('admin');
    }
    public function home()
    {
        return view('admin.home');
    }
    public function create_product_view()
    {
        return view('admin.create_product');
    }
    public function list_product_view()
    {
        $products = new product;
        $products = $products::all();
        return view('admin.list_product_view', compact('products'));
    }
    public function logout()
    {
        session()->flush();
        return redirect('/admin');
    }

    public function create_product(Request $request)
    {
        $products = new product;
        $products->product_name = $request->input('product_name');
        $products->product_type = $request->input('product_type');
        $products->currency = $request->input('currency');
        $products->Asia = $request->input('Asia');
        $products->North_America = $request->input('North_America');
        $products->South_America = $request->input('South_America');
        $products->Antarctica = $request->input('Antarctica');
        $products->Europe = $request->input('Europe');
        $products->Africa = $request->input('Africa');
        $products->Australia = $request->input('Australia');
        $products->ladb_process = $request->input('ladb');

        $products->product_price_wm = $request->input('product_price_wm');
        $products->product_requirements = $request->input('product_requirement');
        $products->product_description = $request->input('product_description');
        $thumbnail = "";
        if ($request->hasFile('image'))
        {
            $image = $request->file('image');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $products->product_logo = $thumbnail;

        $products->save();
        return redirect('/admin/view/product');
    }

    public function edit_product(Request $request, $id)

    {

        $products = product::find($id);

        $products->product_name = $request->input('product_name');
        $products->product_type = $request->input('product_type');
        $products->currency = $request->input('currency');
        $products->Asia = $request->input('Asia');
        $products->North_America = $request->input('North_America');
        $products->South_America = $request->input('South_America');
        $products->Antarctica = $request->input('Antarctica');
        $products->Europe = $request->input('Europe');
        $products->Africa = $request->input('Africa');
        $products->Australia = $request->input('Australia');
        $products->ladb_process = $request->input('ladb');

        $products->product_price_wm = $request->input('product_price_wm');
        $products->product_requirements = $request->input('product_requirement');
        $products->product_description = $request->input('product_description');
        $result = DB::select("select* from products where id = '$id' ");
        $thumbnail = $result[0]->product_logo;

        if ($request->hasFile('image'))
        {
            $image = $request->file('image');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;

        }

        $products->product_logo = $thumbnail;

        $products->save();
        return redirect('/admin/view/product');
    }

    public function specific_product_view($id)
    {
        $product = product::where('id', $id)->get()
            ->first();

        return view('admin.specific_product_view', compact('product'));
    }
    public function delete_product($id)
    {
        product::where('id', $id)->delete();
        return redirect('/admin/view/product');
    }

    public function specific_user_view($id)
    {
        $user = db::select("select* from users where id = '$id'");

        return view('admin.specific_user_view', compact('user'));
    }
    public function delete_user($id)
    {
        user::where('id', $id)->delete();
        return redirect('/admin/users/list');
    }

    public function list_order_active_view()
    {
        $order = order::all()->where('status', '1');
        return view('admin.list_active_order', compact('order'));
    }
    public function order_active_view($id)
    {

        $tabs = DB::select("select requirment_for from additional_requirements where order_id = '$id' and status = 0");

        $new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='Web'");
        $pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='Web' ");
        $approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='Web'");
        $pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='Web'");
        $complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='Web'");

        $Android_new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='Android'");
        $Android_pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='Android' ");
        $Android_approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='Android'");
        $Android_pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='Android'");
        $Android_complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='Android'");

        $IOS_new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='IOS'");
        $IOS_pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='IOS' ");
        $IOS_approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='IOS'");
        $IOS_pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='IOS'");
        $IOS_complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='IOS'");

        $order = order::find($id);

        $date = date('Y-m-d');

        $order = order::find($id);

        $tdate = $order
            ->created_at
            ->format('Y-m-d');

        $datetime1 = new DateTime($tdate);
        $datetime2 = new DateTime($order->expected_delivery);

        $interval = $datetime1->diff($datetime2);
        $tdays = $interval->format('%a');

        //  return $tdays;
        $datetime1 = new DateTime($date);
        $datetime2 = new DateTime($order->expected_delivery);
        $interval = $datetime1->diff($datetime2);

        $days = $interval->format('%a');
        //return $days;
        $cdays = $tdays - $days;
        //return $cdays;
        

        if ($tdays == 0)
        {
            $p = 0;
        }
        else
        {
            $p = ($cdays / $tdays) * 100;
        }

        if ($tdays == 0)
        {
            $e = 0;
        }
        else
        {
            $e = ceil(($days / $tdays) * 100);
        }

        $str = $order->additional_requirements;
        $new = "";
        $pending = "";
        $approve = "";

        $tok = strtok($str, "\n");

        if ($tok[0] == '*')
        {
            $pending = $tok;
            $array1 = array_wrap($pending);
        }
        else
        {
            $new = $tok;
            $array3 = array_wrap($new);
        }
        $array1 = array_wrap($pending);
        $array3 = array_wrap($new);

        while ($tok !== false)
        {
            $tok = strtok("\n");

            if (is_string($tok))
            {
                if ($tok[0] == '*')
                {
                    $pending = $tok;

                    array_push($array1, $pending);
                    //  $skillset= $tok;
                    
                }
                else
                {
                    $new = $tok;
                    array_push($array3, $new);

                }

            }
            //  $array = array_prepend($array, $skillset);
            // array_push($array, $skillset);
            
        }

        $user = User::find($order->customer_id);
        return view('admin.view_active_order', compact('tabs', 'order', 'user', 'array3', 'array1', 'id', 'new_requirements', 'IOS_new_requirements', 'Android_new_requirements', 'pending_requirements', 'IOS_pending_requirements', 'Android_pending_requirements', 'approved_requirements', 'IOS_approved_requirements', 'Android_approved_requirements', 'pcomplete_requirements', 'IOS_pcomplete_requirements', 'Android_pcomplete_requirements', 'complete_requirements', 'IOS_complete_requirements', 'Android_complete_requirements', 'days', 'p', 'e', 'tdays', 'datetime1', 'datetime2'));

    }
    public function reject_pending_requirements($id, Request $request)
    {
        $status = 1;
        $set = 0;
        $content = $request->input('content');
        $charges = '';
        $days = '';
        foreach ($content as $req)
        {
            DB::update(DB::raw("update additional_requirements set status ='$set', charges='$charges', days='$days' WHERE order_id = :value AND additional_requirements = :value1  AND status = :value2 ") , array(
                'value' => $id,
                'value1' => $req,
                'value2' => $status,
            ));

        }
        return redirect()->back();

    }

    public function reject_waiting_requirements($id, Request $request)
    {
        $status = 3;
        $set = 2;
        $content = $request->input('content');

        foreach ($content as $req)
        {
            DB::update(DB::raw("update additional_requirements set status ='$set' WHERE order_id = :value AND additional_requirements = :value1  AND status = :value2 ") , array(
                'value' => $id,
                'value1' => $req,
                'value2' => $status,
            ));

        }
        return redirect()->back();

    }

    public function new_pending_requirements($id, Request $request)
    {

        $status = 1;
        $content = $request->input('content');

        //   return $content;
        $charges = $request->input('charges');

        $days = $request->input('days');

        if (!empty($days) and $charges >= 0)

        {
            foreach ($content as $req)
            {

                DB::update(DB::raw("update additional_requirements set status ='$status', charges='$charges', days='$days' WHERE order_id = :value AND additional_requirements = :value1 ") , array(
                    'value' => $id,
                    'value1' => $req,
                ));

                //   DB::update("update additional_requirements set status ='$status', charges='$charges', days='$days' where order_id='$id' and additional_requirements='$req' ");
                
            }
        }
        else
        {

            foreach ($content as $req)

            {

                DB::delete("delete from additional_requirements where order_id = '$id' and additional_requirements = '$req' ");

            }

        }

        return redirect()->back();

    }

    public function approved_pcomplete_requirements($id, Request $request)
    {
        $status = 3;
        $content1 = $request->input('content1');

        foreach ($content1 as $req)
        {

            //     DB::update("update additional_requirements set status ='$status' where order_id='$id' and additional_requirements='$req' ");
            DB::update(DB::raw("update additional_requirements set status ='$status' WHERE order_id = :value AND additional_requirements = :value1 ") , array(
                'value' => $id,
                'value1' => $req,
            ));

        }

        /*    $order = order::find($id);
          
                            $str = $order->additional_requirements;
                    
                             $a = $request->input('content1');
                   
                      
        
        $tok = strtok($str, "\n");
        
        $skillset =$tok;
        $array = array_wrap($skillset);
        
        while ($tok !== false) {
        $tok = strtok("\n");
        
        if(is_string($tok))
        $skillset= $tok;
        //  $array = array_prepend($array, $skillset);
        array_push($array, $skillset);
        
        }
        
        array_pop($array);
        
        $final[] = "";
        
        
          
            foreach($array as $arrays)
        {
            foreach($a as $as)
        {
            $test =    substr(trim($as), 0, -1);
        
        $test1 =    substr(trim($arrays), 0, -1);
        
        
        if($test == $test1)
        {
        $c = '*'.$arrays;
          array_push($final, $c);
        Break;
        }
        
          
        }
         if($test != $test1)
        {
        
        array_push($final, $arrays);
        }
        }
        
        array_shift($final);
        $final =  implode("\n",$final);
        $orders = order::find($id);
        $orders->additional_requirements = $final;
        $orders->save();*/
        return redirect()->back();

    }

    public function order_active_reporting($id)
    {
        $ui = order_ui_report::all()->where('order_id', $id);
        $web = order_web_report::all()->where('order_id', $id);
        $and = order_android_report::all()->where('order_id', $id);
        $ios = order_ios_report::all()->where('order_id', $id);

        return view('admin.order_reporting', compact('id', 'ui', 'web', 'and', 'ios'));
    }

    public function add_ui_reporting_view($id)
    {
        return view('admin.add_ui', compact('id'));
    }

    public function add_ui_reporting($id, Request $request)
    {
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        DB::insert("insert into order_ui_reports (order_id,header,comments,file,created_at,updated_at) values (?,?,?,?,?,?)", array(
            $id,
            $request->input('header') ,
            $request->input('comment') ,
            $thumbnail,
            Now() ,
            Now()
        ));
        return redirect('/admin/view/order/active/reporting/' . $id);
    }

    public function add_web_reporting_view($id)
    {
        return view('admin.add_web', compact('id'));
    }
    public function add_web_reporting($id, Request $request)
    {
        $web = new order_web_report();
        $web->week_name = $request->input('week_name');
        $web->order_id = $id;
        $web->requirements = $request->input('requirements');
        $web->save();
        return redirect('/admin/view/order/active/reporting/' . $id);
    }
    public function add_android_reporting_view($id)
    {
        return view('admin.add_android', compact('id'));
    }
    public function add_android_reporting($id, Request $request)
    {
        $and = new order_android_report();
        $and->week_name = $request->input('week_name');
        $and->order_id = $id;
        $and->requirements = $request->input('requirements');
        $and->save();
        return redirect('/admin/view/order/active/reporting/' . $id);
    }
    public function add_ios_reporting_view($id)
    {
        return view('admin.add_ios', compact('id'));
    }
    public function add_ios_reporting($id, Request $request)
    {
        $ios = new order_ios_report();
        $ios->week_name = $request->input('week_name');
        $ios->order_id = $id;
        $ios->requirements = $request->input('requirements');
        $ios->save();
        return redirect('/admin/view/order/active/reporting/' . $id);
    }

    public function list_order_new_view()
    {
        $order = order::all()->where('status', '2');
        return view('admin.list_new_order', compact('order'));
    }
    public function order_new_view($id)
    {

        $result = DB::select("select * from additional_requirements where order_id = '$id' and status = '0'");
        $order = order::find($id);
        $user = User::find($order->customer_id);
        return view('admin.view_new_order', compact('order', 'user', 'result'));
    }
    public function new_order_done_1_view($id)
    {
        /* $order = order::find($id);
        $order->status= 1;
        $order->save();
        */
        $result = DB::select("select * from orders where id = '$id'");
        $total = $result[0]->total;
        $cash_slip = $result[0]->cash_slip;
        $first_installment = $result[0]->first_installment;

        return view('admin.new_order_done_1', compact('id', 'result', 'total', 'first_installment', 'cash_slip'));
    }
    public function new_order_done_2_view($id)
    {

        return view('admin.new_order_done_2', compact('id'));
    }

    public function new_order_done_1(Request $request, $id)
    {
        // $order = order::find($id);
        // $order->d1=$request->input("d1");
        // $order->first_installment=$request->input("fi");
        // $order->save();
        // $result = DB::select("select * from orders where id = '$id'");
        // $a=        $result[0]->total;
        //  $c = $a / 2;
        //  DB::update("update orders set first_installment ='$c' where id='$id'");
        return redirect('/admin/view/order/confirm/new/installment/2/' . "$id");
    }
    public function new_order_done_2(Request $request, $id)
    {
        $order = order::find($id);
        $order->d2 = $request->input("d2");
        $order->second_installment = $request->input("si");
        $order->total = $order->first_installment + $request->input("si");
        $order->status = 1;
        $order->expected_delivery = $request->input("ed");
        $order->save();
        return redirect('/admin/view/order/active');
    }

    public function update_order_view($id)
    {
        $charges = DB::select("select* from orders where id = '$id'");

        return view('admin.active_update_order', compact('id', 'charges'));
    }

    public function update_order($id, Request $request)
    {

        $orders = order::find($id);
        $orders->first_installment = $request->input('apaid');
        $orders->total = $request->input('tprice');
        $orders->second_installment = $request->input('tprice') - $request->input('apaid');
        $orders->d2 = $request->input('d1');
        $orders->expected_delivery = $request->input('ed');
        $orders->save();
        //  $date = $request->input('ed');
        //   DB::update("update additional_requirements set days ='$date' where order_id='$id' and status = '1'");
        return redirect('/admin/view/order/active');
    }

    public function list_order_completed_view()
    {
        $order = order::all()->where('status', '3');
        return view('admin.completed_order', compact('order'));
    }
    public function list_order_cancelled_view()
    {
        $order = order::all()->where('status', '4');
        return view('admin.cancel_order', compact('order'));
    }
    public function list_order_refunded_view()
    {
        $order = order::all()->where('status', '5');
        return view('admin.refunded_order', compact('order'));
    }

    public function user_list_view()
    {
        $user = User::all();
        return view('admin.list_new_users', compact('user'));
    }
    public function active_order_edit_additional_view($id)
    {

        $o = order::find($id);
        return view('admin.edit_additional', compact('o', 'id'));
    }

    public function edit_product_view($id)
    {

        $o = product::find($id);

        return view('admin.edit_product', compact('o', 'id'));
    }

    public function active_order_edit_base_view($id)
    {
        $o = order::find($id);
        return view('admin.edit_base', compact('o', 'id'));
    }

    public function active_order_edit_base(Request $request, $id)
    {
        $o = order::find($id);
        $o->base_requirements = $request->input('br');
        $o->save();

        return redirect('/admin/view/order/active/' . $id);

    }
    public function active_order_edit_additional(Request $request, $id)
    {
        $o = order::find($id);
        $o->additional_requirements = $request->input('br');
        $o->save();

        return redirect('/admin/view/order/active/' . $id);

    }

    public function view_developers()
    {
        $developer = developer::all();
        return view('admin.view_developers', compact('developer'));
    }
    public function create_developers_view()
    {
        return view('admin.create_developers');
    }

    public function create_developers(Request $request)
    {
        $u = $request->input('email');
        $r = db::select("select* from developers where email='$u'");
        if (count($r) > 0)
        {
            return redirect('admin-view-developers')->with('emessage', 'Developer Already Exist');
        }
        $d = new developer();
        $d->fname = $request->input('first_name');
        $d->lname = $request->input('last_name');
        $d->email = $request->input('email');
        $d->password = bcrypt($request->input('password'));
        $d->role = $request->input('role');
        $d->save();
        return redirect('admin-view-developers')
            ->with('message', 'Developer Successfully Created');
    }

    public function assign_developer_project_view($id)
    {
        $o = order::where('status', 1)->get();
        return view('admin.assign_project', compact('o', 'id'));
    }
    public function assign_developer_project(Request $request, $id)
    {
        $a = new project_assignment();
        $a->project_id = $request->input('project_id');
        $a->developer_id = $id;
        $a->save();
        return redirect('/admin-developer-view-project-assign/' . $id)->with('message', 'Project Successfully Assigned');
    }
    public function view_assigned_projects($id)
    {
        $a = db::select("select project_assignments.id as tid,project_assignments.project_id as pid,orders.his_product_name as pname from orders,project_assignments where project_assignments.developer_id = '$id' and project_assignments.project_id = orders.id");

        return view('admin.view_assigned_projects', compact('a', 'id'));
    }

    public function create_tasks_view($project_id, $developer_id)
    {

        return view('admin.create_tasks', compact('project_id', 'developer_id'));
    }

    public function create_tasks(Request $request, $project_id, $developer_id)
    {
        $t = new task();
        $t->name = $request->input('name');
        $t->date = $request->input('date');
        $t->project_id = $project_id;
        $t->developer_id = $developer_id;
        $t->save();
        return redirect('/admin-developer-project-view-tasks/' . $project_id . '/' . $developer_id)->with('message', 'You have successfully created a task');
    }
    public function tasks_list($project_id, $developer_id)
    {
        $t = task::where('project_id', $project_id)->where('developer_id', $developer_id)->get();
        session()
            ->put('p_id', $project_id);
        return view('admin.developer_project_task_list', compact('t'));
    }

    public function create_tasks_task_list_view($id)
    {
        $project_id = session()->get('p_id');
        $order = db::select("select* from orders where id = '$project_id'");

        $str = $order[0]->additional_requirements;
        $tok = strtok($str, "\n");
        if ($tok[0] == "*")
        {
            $tok[0] = ' ';

        }
        else
        {
            $skillset = "<select class=form-control name=to_do[]> <option value='$tok'>" . $tok . "</option>";
        }
        while ($tok !== false)
        {

            $tok = strtok("\n");

            if (is_string($tok)) if ($tok[0] == "*")
            {
                $tok[0] = ' ';

            }
            else
            {
                $skillset = $skillset . "<option value='$tok'>" . $tok . "</option>";
            }

        }
        $skillset = $skillset . "</select>";

        return view('admin.create_tasks_task_list_view', compact('id', 'skillset'));
    }

    public function create_tasks_task_list_post(Request $request, $id)
    {

        $to_do = $request->input('to_do');
        $priority = $request->input('priority');

        $index = sizeof($to_do);
        for ($i = 0;$i < $index;$i++)
        {
            if (!empty($to_do[$i]) && !empty($priority[$i]))
            {
                $t = new tasklist();
                $t->task_id = $id;
                $t->to_do = $to_do[$i];
                $t->status = "pending";
                $t->priority = $priority[$i];
                $t->save();
            }
        }

        return redirect('admin-view-developers/')
            ->with('message', 'Task list Successfully Created');
    }

    public function tasks_task_list_view($id)
    {
        $t = tasklist::where('task_id', $id)->get();

        return view('admin.tasks_task_list_view', compact('t', 'id'));
    }

    public function delete_tasks_task_list($ttid, $tid)
    {
        tasklist::find($ttid)->delete();

        return redirect('/admin-developer-project-view-tasks-list/' . $tid)->with('message', 'Task has been deleted');
    }
    public function deleteDeveloper($id)
    {
        developer::find($id)->delete();

        return redirect('admin-view-developers')
            ->with('message', 'Developer Successfully Deleted');
    }

    public function cancel_active_order($id)
    {
        $o = order::find($id);
        $o->status = 4;
        $o->save();
        return redirect()
            ->back();
    }

    public function create_links_view()
    {
        $product = db::select("select DISTINCT product_name from products");

        return view('admin.create_links', compact('product'));
    }

    public function edit_links_view($id)
    {

        $product = db::select("select * from custom_links where pk_id = '$id'");
        $result = db::select("select DISTINCT product_name from products");
        return view('admin.edit_links', compact('product', 'result'));
    }
    public function create_links(Request $request)
    {

        $l = new custom_link();
        $l->product_name = $request->input('product_name');
        $l->ladb_process = $request->input('ladb_process');
        $l->custom_url = $request->input('custom_url');
        $l->price = $request->input('price');
        $l->currency = $request->input('currency');
        $l->save();
        return redirect('admin-view-links')
            ->with('message', 'Link Successfully Created');
    }

    public function edit_links(Request $request, $id)
    {

        DB::table('custom_links')->where('pk_id', $id)->update(['product_name' => $request->input('product_name') , 'ladb_process' => $request->input('ladb_process') , 'custom_url' => $request->input('custom_url') , 'price' => $request->input('price') , 'currency' => $request->input('currency') ]);

        return redirect('admin-view-links')
            ->with('message', 'Link Successfully Edit');
    }
    public function delete_links($id)
    {

        DB::delete("delete from custom_links where pk_id = '$id'");

        return redirect('admin-view-links')->with('message', 'Link Successfully Edit');
    }
    public function view_links()
    {
        $links = db::select("select * from custom_links order by pk_id desc");
        //  $links = custom_link::all()->sortByDesc("pk_id");
        return view('admin.view_links', compact('links'));
    }

    public function subscription_payment()
    {

        return view('admin.subscribtion');
    }

    public function ecom_active_order()
    {
        $result = DB::select("select* from ecom_order");
        return view('admin.ecom_order_list', compact('result'));

    }
    public function ecom_order_detail($id, $email)
    {
        // return $id;
        $user = db::select("select* from users,ecom_order where users.username= ecom_order.email and users.username = '$email' and ecom_order.pk_id='$id'");

        return view('admin.ecom_order_detail', compact('user'));
    }

    public function wordpress_active_order()
    {
        $result = DB::select("select* from wordpress_order");
        return view('admin.wordpress_order_list', compact('result'));

    }

    public function wordpress_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        $status = $request->input('status');

        if ($status == '1')
        {
            $current = Carbon::now();
            $trialExpires = $current->addDays(7);
            DB::update("update wordpress_order set status='$status',deliverydate='$trialExpires' ,start_date=NOW() where pk_id='$id'");
        }
        else
        {

            DB::update("update wordpress_order set status='$status' where pk_id='$id'");
        }
        return URL('/') . "/wordpress/active/order";
    }

    public function projects()
    {

        $result = order::all()->where('status', '1');
        return view('admin.project_list', compact('result'));
    }
    public function view_task($id)
    {

        $result = order::all()->where('id', $id);
        
        $result5 = DB::select("select * from task where o_id = '$id'");
        
        $story_point = DB::table('task')->where('o_id',$id)->sum('story_point');
        
        $developer = DB::select("select * from developers");
        
        // $task = DB::select("select users.username,users.fname,users.lname,task.task,task.status,task.updated_at from task,users where users.id= task.customer_id and task.status = '0' and  week(task.updated_at)=week(now())");
        
        
        $result6 = DB::select("select * from task where o_id = '$id' and status ='2'");
        return view('admin.active_task_list', compact('result','id', 'developer','result5','result6','story_point'));

    }
    
    public function search_task(Request $request)
    {
        $id = $request->Input('o_id');
        $week = $request->Input('week');
        $developer = $request->Input('developer');
        $task_type = $request->Input('task_type');
        
        
        if (!empty($week) && !empty($task_type))
        {
        
        if ($week == "This Week" and  $task_type == "All")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and  week(created_at)=week(now())");
            
        }
        
        elseif ($week == "Last Week" and  $task_type == "All")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and  week(created_at)=week(now())-1");
            
        }
        
        elseif ($week == "This Week" and  $task_type == "1")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status='1' and  week(created_at)=week(now())");
            
        }
        
        elseif ($week == "Last Week" and  $task_type == "1")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status='1' and  week(created_at)=week(now())-1");
            
        }
        
        elseif ($week == "This Week" and  $task_type == "2")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status='0' and  week(created_at)=week(now())");
            
        }
        
        elseif ($week == "Last Week" and  $task_type == "2")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status='0' and  week(created_at)=week(now())-1");
            
        }
        
        }
        
        
        if (!empty($week))
        {
        
        if ($week == "This Week")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and  week(created_at)=week(now())");
            
        }
        
        elseif ($week == "Last Week")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and  week(created_at)=week(now())-1");
            
        }
        
        }
        
        if (!empty($developer))
        {
            
            
        if ($developer == "All")
        {
            
            $result5 = DB::select("select * from task where o_id = '$id'");
            
        }
        
        else
        {
            $result5 = DB::select("select * from task where o_id = '$id' and developer_name ='$developer'");
            
        }
        }
        
        if (!empty($task_type))
        {
            
            
        if ($task_type == "All")
        {
            
            $result5 = DB::select("select * from task where o_id = '$id'");
            
        }
        
        elseif($task_type == "1")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status ='1'");
            
        }
        elseif($task_type == "2")
        {
            $result5 = DB::select("select * from task where o_id = '$id' and status ='0'");
            
        }
        
        }
        
        $result = order::all()->where('id', $id);
        

        $developer = DB::select("select * from developers");
        
        $story_point = DB::table('task')->where('o_id',$id)->sum('story_point');

        return view('admin.active_task_list', compact('result', 'result5','id', 'developer','story_point'));

    }
    
    public function sub(Request $request)
    {
        $value = $request->Input('cat_id');
        $o_id = $request->Input('o_id');
        
        $week = $request->Input('week');
        $developer = $request->Input('developer');
        
            $developers = DB::select(DB::raw("SELECT * FROM developers WHERE developers.id = :value") , array(
            'value' => $developer,
        ));

        if (count($developers) > 0)
        {
            $developer_name = $developers[0]->fname . ' ' . $developers[0]->lname;
        }
        
        if ($week == "0")
        {
        $subcategories = DB::select(DB::raw("SELECT * FROM task WHERE status = :value and o_id =:value2 and developer_name= :value3 and week(created_at)=week(now())") , array(
            'value' => $value,
            'value2' => $o_id,
            'value3' => $developer_name,
        ));
        }elseif ($week == "1")
        {
        $subcategories = DB::select(DB::raw("SELECT * FROM task WHERE status = :value and o_id =:value2 and developer_name= :value3 and week(created_at)=week(now())-1") , array(
            'value' => $value,
            'value2' => $o_id,
            'value3' => $developer_name,
        ));
        }
        
        
        

        return $subcategories;

    }

    public function abc(Request $request)
    {
        $main = $request->Input('developer');

        $id = $request->Input('o_id');
        
        $week = $request->Input('week');
        
        if (!empty($main) && !empty($week))
        {
            
        
        
        if ($main == "All" and $week == "This Week")
        {
            $result2 = DB::select("select * from task where o_id = '$id' and status = '0' and  week(created_at)=week(now())");
        }
        
        elseif ( $main == "All" and $week == "Last Week")
        {
            $result2 = DB::select("select * from task where o_id = '$id' and status = '0' and  week(created_at)=week(now())-1");
        }
        
        elseif($main == $request->Input('developer') && $week == "Last Week")
        {
            $main = $request->Input('developer');
            $developers = DB::select(DB::raw("SELECT * FROM developers WHERE developers.id = :value") , array(
            'value' => $main,
        ));

        if (count($developers) > 0)
        {
            $developer_name = $developers[0]->fname . ' ' . $developers[0]->lname;
        }
            $result2 = DB::select("select * from task where developer_name = '$developer_name' and status = '0' and o_id= '$id' and week(created_at)=week(now())-1");
        }
        
        elseif($main == $request->Input('developer') && $week == "This Week")
        {
            $main = $request->Input('developer');
            $developers = DB::select(DB::raw("SELECT * FROM developers WHERE developers.id = :value") , array(
            'value' => $main,
        ));

        if (count($developers) > 0)
        {
            $developer_name = $developers[0]->fname . ' ' . $developers[0]->lname;
        }
            $result2 = DB::select("select * from task where developer_name = '$developer_name' and status = '0' and o_id= '$id' and week(created_at)=week(now())");
        }
        
        }
        
        

        $result = order::all()->where('id', $id);

        $developer = DB::select("select * from developers");

        $result3 = DB::select("select * from task where o_id = '$id' and status = '1'");

        return view('admin.active_task_list', compact('result', 'result2', 'result3', 'id', 'developer'));

    }

    public function add_task_view($id)
    {

        $result = DB::select("select * from orders where id = '$id'");

        $result2 = DB::select("select * from developers");

        return view('admin.create_task', compact('result', 'result2'));
    }

    public function add_task(Request $request)
    {

        $pname = $request->input('pname');

        $customer_id = $request->input('customer_id');
        $dname = $request->input('dname');

        $q = $request->input('mytextt');

        $o_id = $request->input('id');

        for ($i = 0;$i < count($q);$i++)
        {

            DB::insert("insert into task (o_id,project_name,customer_id,developer_name,task,story_point) values (?,?,?,?,?,?)", array(
                $o_id,
                $pname,
                $customer_id,
                $dname,
                $q[$i],
                $q[++$i]
            ));

        }

        return redirect("/admin/view/task/" . $o_id);
    }

    public function complete_task($id, Request $request)
    {
        $date = date('Y-m-d');
        $status = 1;
        $content = $request->input('content');

        foreach ($content as $req)
        {
            DB::update(DB::raw("update task set status ='$status',updated_at ='$date' WHERE o_id = :value AND task = :value1 ") , array(
                'value' => $id,
                'value1' => $req,
            ));
            
        }
        
        
            // $result = DB::select("select* from task where o_id = '$id' and status = '$status' and updated_at = '$date'");
            
            // $customer_id = $result[0]->{'customer_id'};
            // $username = DB::select("select* from users where id = '$customer_id'");
            //                           $user_email = $username[0]->{'username'};
            //                           $name = $username[0]->{'fname'} .' ' . $username[0]->{'lname'};
            
        //     $data = array(
        //         'task' => $result,
        //         'name' => $name,
        //     );
        //     Mail::send('task_complete', $data, function ($message) use ($user_email)
        //   {
              
        //       $message->from('info@general.greengrapez.com', 'Green Grapez');
        //       $message->to('support@greengrapez.com')->subject('Task Complete Email');
        //   });
        //   Mail::send('task_complete', $data, function ($message) use ($user_email)
        //   {
        //       $message->from('info@general.greengrapez.com', 'Green Grapez');
        //       $message->to($user_email)->subject('Task Complete Email');
        //   });
          
          

        
        return redirect("/admin/view/task/" . $id);

    }
    
    public function active_sprint_task($id, Request $request)
    {
        $date = date('Y-m-d');
        $status = 0;
        $content = $request->input('content');

        foreach ($content as $req)
        {
            DB::update(DB::raw("update task set status ='$status',updated_at ='$date' WHERE o_id = :value AND task = :value1 ") , array(
                'value' => $id,
                'value1' => $req,
            ));
            
        }
        
        return redirect("/admin/view/task/" . $id);

    }
    
    public function date()
    {
    
    $id="34";
    
    
        
        // $date = DB::select("select * from task where o_id = '$id' and status = '1' and created_at BETWEEN DATE_SUB( CURDATE() ,INTERVAL 10 DAY ) AND CURDATE()");

        // $date = DB::select("select * from task where o_id = '$id' and status = '0' and  week(created_at)=week(now())-1");
        $date = DB::select("select  users.username,users.fname,users.lname , task.task, task.status,task.updated_at from task,users where users.id= task.customer_id  and status = '0' and  week(task.updated_at)=week(now())");
        
        $email = DB::select("select DISTINCT  users.username,users.fname,users.lname from task,users where users.id= task.customer_id  and status = '0' and  week(task.updated_at)=week(now())");

        
        $studivs = array();
        foreach ($email as $req)
        {
            $studivs[]=$req->username; 
        }
        
              return $studivs;

    }
    
}

