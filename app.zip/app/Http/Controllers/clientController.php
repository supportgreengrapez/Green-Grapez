<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Mail;
use DateTime;
use App\custom_link;
use Illuminate\Http\Request;
use App\User;
use Auth;
use Session;
use App\product;
use App\order;
use App\order_ui_report;
use App\order_ios_report;
use App\order_android_report;
use App\order_web_report;
use App\blogpost;
use App\enquire;
use Socialite;
use Carbon\Carbon;
class clientController extends Controller
{

    public function add_all_additional_requirement()
    {
        $id = 94;
        $header = "old requirements";
        $status = 2;
        $result = DB::select("select* from  orders where id = '$id'");

        $tok = $result[0]->additional_requirements;

        $tok = strtok($tok, "\n");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok("\n");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }
        array_pop($array);
        foreach ($array as $req)
        {

            if ($req[0] == "*")
            {
                $req = ltrim($req, $req[0]);
            }

            $req = trim(preg_replace('/\s+/', ' ', $req));
            DB::insert("insert into additional_requirements (order_id,header,additional_requirements,status,created_at) values (?,?,?,?,?)", array(
                $id,
                $header,
                $req,
                $status,
                NOW()
            ));
        }

        return "true";
        return redirect()->back()
            ->with('message', 'You have Successfully added addition requirement, Please wait our Customer Support will review and confirm you by call or email');
    }

    public function csv(Request $request)
    {

        $requestBody = $request->all();

        //get file
        $upload = $request->file('file');
        $filePath = $upload->getRealPath();
        //open and read
        $file = fopen($filePath, 'r');
        $header = fgetcsv($file);
        // dd($header);
        $escapedHeader = [];
        //validate
        foreach ($header as $key => $value)
        {
            $lheader = strtolower($value);
            $escapedItem = preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);

        }
        //looping through othe columns
        while ($columns = fgetcsv($file))
        {
            if ($columns[0] == "")
            {
                continue;
            }
            //trim data
            /*    foreach ($columns as $key => &$value) {
            $value = strtok($value, ",");
            //   return $value;
            }*/
            $data = array_combine($escapedHeader, $columns);

            // setting type
            /*    foreach ($data as $key => &$value) {
            $value=($key=="SKU")?(integer)$value: (float)$value;
            }*/
            // Table update
            $currency = $data['currency'];

            $symbol = $data['symbol'];

            DB::table('country')->where('currency', $currency)->update(['currency_symbol' => $symbol]);

        }

        return "added successfully";

    }

    public function ip(Request $request)
    {
        $currency = 'EUR';

        $symbol = '€';
        DB::table('country')->where('currency', $currency)->update(['currency_symbol' => $symbol]);

        return "true";

        $str = file_get_contents("http://country.io/currency.json");

        $tok = strtok($str, ",");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok(",");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }

        array_pop($array);

        foreach ($array as $arrays)
        {
            $tok1 = strtok($arrays, ":");
            $skillset1 = $tok1;
            $array1 = array_wrap($skillset1);

            while ($tok1 !== false)
            {
                $tok1 = strtok(":");

                if (is_string($tok1)) $skillset1 = $tok1;
                //  $array = array_prepend($array, $skillset);
                array_push($array1, $skillset1);

            }

            array_pop($array1);

            $c = count($array1);
            if ($c == 2)
            {
                $dataList = substr($array1[0], 2, -1);
                $dataList1 = substr($array1[1], 2, -1);

                //  DB::insert("insert into country (id,name ) values (?,?)",array($dataList,$dataList1));
                DB::table('country')->where('id', $dataList)->update(['currency' => $dataList1]);

            }

        }

        return "true";

        $response = Unirest\Request::get("https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/quickAnswer?q=How+much+vitamin+c+is+in+2+apples%3F", array(
            "X-RapidAPI-Key" => "048971c482mshb1daef0c0779957p182aebjsnedff8b0665fe"
        ));

        return $response;

    }
    public function delete_new_requirements($id, Request $request)
    {
        $status = 0;
        $content = $request->input('content');
        foreach ($content as $req)
        {
            DB::delete("delete from additional_requirements where order_id = '$id' and additional_requirements = '$req' and status = '$status'");

        }
        return redirect()->back();

    }

    public function verify_code($username, $code)
    {
        $result = DB::select("select* from reset_password where username= '$username' and verification_code= '$code' and TIMESTAMPDIFF(MINUTE,reset_password.created_at,NOW()) <=30 ");

        if (count($result) > 0)
        {
            return view('client.change_password', compact('username'));
        }
        else return "The Verification code is expired";
    }

    public function reset_password_view()
    {

        return view('client.password_reset');

    }

    public function reset_password(Request $request)
    {

        $username = $request->input('username');
        $result = DB::select("select* from users where username = '$username'");
        if (count($result) > 0)
        {
            $vcode = uniqid();
            DB::insert("insert into reset_password (username,verification_code) values('$username','$vcode') ");
            $customer_name = $result[0]->{'fname'};
            $data = array(
                'customer_name' => $customer_name,
                'customer_username' => $username,
                'customer_verification_code' => $vcode,

            );
            Mail::send('email_reset_password', $data, function ($message) use ($username)
            {

                $message->from('support@greengrapez.com', 'GREEN GRAPEZ');

                $message->to($username)->subject('Password Reset Confirmation Link');

            });
            return redirect()
                ->back()
                ->with('message', 'A Password reset link sent to your email');
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username not found');
        }

    }

    public function password_change(Request $request, $username)
    {
        $password = md5($request->input('password'));
        DB::update("update users set password ='$password' where username='$username'");
        return redirect('/login')->with('message', 'Your Password has been changed Successfully');
    }

    public function custom_order_register(Request $request)
    {
        if (count(User::all()->where('username', $request->input('email'))) > 0)
        {
            return "user already exist";
        }

        $u = new User;
        $u->fname = $request->input('fname');
        $u->lname = $request->input('lname');
        $u->username = $request->input('email');
        $u->password = bcrypt($request->input('password'));
        $u->city = $request->input('city');
        $u->country = $request->input('country');
        $u->state = $request->input('state');
        $u->phone = $request->input('phone');
        $u->save();

        $userdata = array(
            'username' => $request->input('email') ,
            'password' => $request->input('password')
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $request->input('email'));
            session()
                ->put('type', 'client');
            return $this->confirm_custom_order();

        }
        return redirect('/login');

    }
    public function custom_order_register_view()
    {
        return view('custom_order_register');
    }

    public function cart_view()
    {

        return view('cart_view');
    }

    public function payment_view()
    {
        return view('payments');
    }

    public function slip_views(Request $request)
    {
        $thumbnails = "";
        if ($request->hasFile('slip'))
        {
            $image = $request->file('slip');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnails = $uniqueFileName;
        }
        session()->put('order.cash_slip', $thumbnails);
        return view('cart_view');

    }

    public function custom_slip_views(Request $request)
    {
        $p = session()->get('price');
        $d = session()->get('description');
        $c = session()->get('content');
        $ph = session()->get('photo');

        $total = $p + $d + $c + $ph;
        $first_installment = $total / 2;
        session()->put('total_price', $total);
        session()->put('first_installment', $first_installment);
        $thumbnails = "";
        if ($request->hasFile('slip'))
        {
            $image = $request->file('slip');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnails = $uniqueFileName;
        }
        session()->put('order.cash_slip', $thumbnails);
        return view('custom_cart_view');

    }

    public function custom_payment_view()
    {
        return view('custome_payments');
    }

    public function enquiry_view()
    {
        return view('custom-req-form');
    }

    public function order_custom_login_view()
    {

        if (session()->has('username'))
        {
            return redirect('client/dashboard');
        }
        else
        {
            return view('custom_order_login');
        }
    }
    public function order_custom_login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $userdata = array(
            'username' => $username,
            'password' => $password
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $username);
            session()->put('type', 'client');

            return $this->confirm_custom_order();

        }
        else return view('login_view')
            ->witherror("username or password is incorrect");
    }

    public function confirm_custom_order()
    {
        $a = session()->get("order");
        $url = $a["url"];;
        $font_family = $a["font_family"];;
        $des = $a["des"];;
        $req = $a["requirement"];;

        $order = new enquire;

        $order->product_name = $a["product_name"];
        $order->industry = $a["industry"];
        $order->user_id = Auth::user()->id;
        $order->c1 = $a["c1"];
        $order->c2 = $a["c2"];
        $order->product_logo = $a["logo"];
        $order->reference_site = $url;
        $order->font_family = $font_family;
        $order->description = $des;

        $order->requirement = $req;
        $order->save();

        return redirect('thankyou');
    }

    public function submit_enquiry(Request $request)
    {
        if (session()->get('type') == 'client')
        {
            $url = $request->input('url');
            $font_family = $request->input('font_family');
            $des = $request->input('description');
            $req = $request->input('mytext');
            $a = session()->get("order");

            $order = new enquire;

            $order->product_name = $a["product_name"];
            $order->industry = $a["industry"];
            $order->user_id = Auth::user()->id;
            $order->c1 = $a["c1"];
            $order->c2 = $a["c2"];
            $order->product_logo = $a["logo"];
            $order->reference_site = $url;
            $order->font_family = $font_family;
            $order->description = $des;
            $s = "";
            foreach ($req as $r)
            {
                if ($r != "") $s .= $r . ",";
            }
            $s = rtrim($s, ',');
            $order->requirement = $s;
            $order->save();

            return redirect('thankyou');
        }
        else
        {
            $url = $request->input('url');
            $font_family = $request->input('font_family');
            $des = $request->input('description');
            $req = $request->input('mytext');
            $s = "";
            foreach ($req as $r)
            {
                if ($r != "") $s .= $r . ",";
            }
            $s = rtrim($s, ',');
            session()->put('order.url', $url);
            session()->put('order.font_family', $font_family);
            session()->put('order.des', $des);
            session()->put('order.requirement', $s);

            return redirect('order/custom/process/login');
        }

    }
    public function detail_blog($id)

    {
        $blog = blogpost::find($id);
        $ba = blogpost::all()->sortByDesc("id");
        return view('blog-single', compact('blog', 'ba'));
    }
    public function blog()
    {
        $blog = blogpost::all()->sortByDesc("id");

        return view('blog', compact('blog'));
    }
    public function socialLogin($social)

    {

        return Socialite::driver($social)->redirect();

    }

    public function handleProviderCallback($social)

    {
        // $oauth_token =  $_GET["oauth_token"];
        //  $oauth_token_secret = $_GET["oauth_verifier"];
        if ($social == "facebook")
        {
            if (!empty($_GET["error"]) && $_GET["error"] == "access_denied")
            {
                return redirect("/login");
            }
            {

            }
        }
        else if ($social == "twitter")
        {
            if (!empty($_GET["denied"]))
            {
                return redirect("/login");
            }
        }
        $userSocial = null;

        //return dd(Socialite::driver($social)->userFromTokenAndSecret($oauth_token, "wBM3ozCBNexwUIPYaMbjFGYDsjT3rxmlBpv54W6jaD6keyUeKI"));
        if ($social == "twitter")
        {
            $userSocial = Socialite::driver($social)->user();
        }
        else if ($social == "facebook")
        {
            $userSocial = Socialite::driver($social)->stateless()
                ->user();
        }
        else
        {
            $userSocial = Socialite::driver($social)->stateless()
                ->user();
        }

        $user = User::where('username', $userSocial->getEmail())
            ->first();

        if ($user)
        {

            Auth::login($user);

            if (Auth::check())
            {

                session()->put('username', $user->username);
                session()
                    ->put('type', 'client');

                return redirect("client/dashboard");
            }
        }
        else
        {

            $user = new User;
            $user->fname = $userSocial->getName();
            $user->username = $userSocial->getEmail();
            $user->save();
            auth::login($user);
            if (Auth::check())
            {

                session()->put('username', $user->username);
                session()
                    ->put('type', 'client');

                return redirect("client/dashboard");
            }
            else return "wrong";
        }

    }

    public function logout()
    {
        session()
            ->flush();
        return redirect('/login');
    }
    public function login(Request $request)
    {
        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $username = $request->input('username');
        $password = md5($request->input('password'));
        $result = DB::select("select* from users where username = '$username' and password='$password' ");

        if (count($result) > 0)
        {
            $request->session()
                ->put('id', $result[0]->{'id'});
            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('type', 'client');
            $request->session()
                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
            $request->session()
                ->put('fname', $result[0]->{'fname'});
            $request->session()
                ->put('lname', $result[0]->{'lname'});
            return Redirect::to('client/dashboard');
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username or Password is incorrect');
        }
    }
    public function register(Request $request)
    {
        if ($request->input('password') == $request->input('cpassword'))
        
        {
            $username = $request->input('email');
            $result = DB::select("select* from users where username = '$username' ");
            if (count($result) > 0)
            {
                return Redirect::back()->withErrors('Username already Exist');
            }
            else
            {
                $password = $request->input('password');
                DB::insert("insert into users (fname,lname, username, password,city,country,state,phone ) values (?,?,?,?,?,?,?,?)", array(
                    $request->input('fname') ,
                    $request->input('lname') ,
                    $request->input('email') ,
                    md5($password) ,
                    $request->input('city') ,
                    $request->input('country'),
                    $request->input('state'),
                    $request->input('phone')
                ));
                
                $this->validate($request, ['email' => 'required', 'password' => 'required']);
                $username = $request->input('email');
                $password = md5($request->input('password'));
                $result = DB::select("select* from users where username = '$username' and password='$password' ");
                
                if (count($result) > 0)
                {
                    $request->session()
                        ->put('id', $result[0]->{'id'});
                    $request->session()
                        ->put('username', $username);
                    $request->session()
                        ->put('type', 'client');
                    $request->session()
                        ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                    $request->session()
                        ->put('fname', $result[0]->{'fname'});
                    $request->session()
                        ->put('lname', $result[0]->{'lname'});
                    return Redirect::to('client/dashboard');
                }
            }
        }
        else
        {
            return Redirect::back()
                ->withErrors('Password does not match');
        }

    }
    public function test()
    {
        return session('username');
    }
    public function order_process_1($ladb)
    {
        session()->put('order.ladb', $ladb);
        return view('product-form1');
    }
    public function order_process_2(Request $request)
    {
        session()->put('order.product_name', $request->input('pname'));
        session()
            ->put('order.industry', $request->input('industry'));
        session()
            ->put('order.c1', $request->input('c1'));
        session()
            ->put('order.c2', $request->input('c2'));
        session()
            ->put('order.additional_requirements', '');
        $thumbnail = "";
        if ($request->hasFile('image'))
        {
            $image = $request->file('image');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        session()->put('order.logo', $thumbnail);

        return redirect('/order/process/step/2');
    }

    public function pricing_process_3(Request $request)
    {
        session()->put('order.product_name', $request->input('pname'));
        session()
            ->put('order.industry', $request->input('industry'));
        session()
            ->put('order.c1', $request->input('c1'));
        session()
            ->put('order.c2', $request->input('c2'));
        session()
            ->put('order.additional_requirements', '');
        $thumbnail = "";
        if ($request->hasFile('image'))
        {
            $image = $request->file('image');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        session()->put('order.logo', $thumbnail);

        return redirect('/order/process/step/3');
    }

    public function order_process_2_view(Request $request)
    {

        $ladb = session()->get("order.ladb");

        $product = product::where('ladb_process', $ladb)->get();
        $ip = $request->ip();

        $string = file_get_contents("https://api.ipdata.co/{$ip}?api-key=9db089e4dc00c8925d3c70fbc37f45f86060a29e854950efe57d9aa0");

        $json = json_decode($string);
        $continent_name = $json->continent_name;

        $code = $json
            ->currency->code;

        return view('product-form2', compact('product', 'code', 'continent_name'));
    }

    public function pricing_page_view($ladb, Request $request)
    {

        // $ladb = session()->get("order.ladb");
        session()->put('order.ladb', $ladb);

        $product = product::where('ladb_process', $ladb)->get();
        $ip = $request->ip();

        $string = file_get_contents("https://api.ipdata.co/{$ip}?api-key=9db089e4dc00c8925d3c70fbc37f45f86060a29e854950efe57d9aa0");

        $json = json_decode($string);
        $continent_name = $json->continent_name;
        $code = $json
            ->currency->code;

        return view('pricing-form2', compact('product', 'code', 'continent_name'));
    }

    public function pricing_2(Request $request)
    {

        if (session()->has('order.our_product') && session()
            ->get('order.our_product') != $request->input('c'))
        {
            session()
                ->put('edit', 'false');
            session()
                ->put('additional', 'false');

        }
        $content = 0;
        $photo = 0;
        $description = 0;
        $p = product::find($request->input('c'));
        if ($request->input('content'))
        {
            $content = $request->input('content');
            session()
                ->put('content', $content);
        }
        if ($request->input('photo'))
        {
            $photo = $request->input('photo');
            session()
                ->put('photo', $photo);
        }
        if ($request->input('description'))
        {
            $description = $request->input('description');
            session()
                ->put('description', $description);
        }

        $price = $request->input('price');
        session()
            ->put('price', $price);

        $total = $photo + $description + $content + $price;
        $first_installment = $total / 2;
        session()->put('total_price', $total);
        session()->put('first_installment', $first_installment);
        session()->put('order.our_product', $p->product_name);

        //return dd(session()->get('order'));
        return redirect('/pricing/step/2');
    }

    public function pricing_2_view(Request $request)
    {

        if (session()->has('order.our_product') && session()
            ->get('order.our_product') != $request->input('c'))
        {
            session()
                ->put('edit', 'false');
            session()
                ->put('additional', 'false');

        }

        return view('pricing-form3');

        //  return redirect('/pricing/step/2');
        
    }

    public function order_process_3(Request $request)
    {

        if (session()->has('order.our_product') && session()
            ->get('order.our_product') != $request->input('c'))
        {
            session()
                ->put('edit', 'false');
            session()
                ->put('additional', 'false');

        }
        $p = product::find($request->input('c'));
        $content = 0;
        $photo = 0;
        $description = 0;
        if ($request->input('content'))
        {
            $content = $request->input('content');
            session()
                ->put('content', $content);
        }
        if ($request->input('photo'))
        {
            $photo = $request->input('photo');
            session()
                ->put('photo', $photo);
        }
        if ($request->input('description'))
        {
            $description = $request->input('description');
            session()
                ->put('description', $description);
        }
        $price = $request->input('price');
        session()
            ->put('price', $price);

        $total = $photo + $description + $content + $price;
        $first_installment = $total / 2;
        session()->put('total_price', $total);
        session()->put('first_installment', $first_installment);
        session()->put('order.our_product', $p->product_name);

        //return dd(session()->get('order'));
        return redirect('/order/process/step/3');
    }
    public function order_process_3_view()
    {

        $p = session()->get('order.our_product');
        $description = session()->get('description');
        $content = session()->get('content');
        $photo = session()->get('photo');

        if (!(session()
            ->get('edit') == 'true'))
        {
            $product = product::where('product_name', $p)->get()
                ->first();
            session()
                ->put('order.base_requirements', $product->product_requirements);

            session()
                ->put('order.price', $product->product_price);
            session()
                ->put('order.price_wm', $product->product_price_wm);
            $product = session()->get('order.base_requirements');

            $addi = session()->get('order.additional_requirements');

            //$result = DB::select("select* from products where product_name = '$p'");
            return view('product-form3', compact('product', 'addi'));
        }
        else
        {
            $addi = session()->get('order.additional_requirements');

            $product = session()->get('order.base_requirements');
            //$result = DB::select("select* from products where product_name = '$p'");
            return view('product-form3', compact('product', 'addi'));
        }
    }
    public function edit_base_requirement_view()
    {
        return view('product-form4');
    }

    public function edit_base_requirement(Request $request)
    {
        $br = $request->input('br');
        session()
            ->put('order.base_requirements', $br);
        session()->put('edit', 'true');
        return redirect('/order/process/step/3');
    }

    public function add_additional_requirement_view()
    {
        return view('product-form5');
    }

    public function add_additional_requirement(Request $request)
    {

        $str = $request->input('mytexttt');
        //  $br = $request->input('br');
        session()
            ->push('order.additional_requirements[]', $str);

        // return $req[0][0];
        session()->put('additional', 'true');
        return redirect('/order/process/step/3');
    }
    public function order_login_view()
    {

        if (session()
            ->has('username'))
        {
            return redirect('client/dashboard');
        }
        else
        {
            return view('order_login');
        }
    }
    public function order_login(Request $request)
    {

        $username = $request->input('username');
        $password = $request->input('password');
        $userdata = array(
            'username' => $username,
            'password' => $password
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $username);
            session()->put('type', 'client');

            return $this->confirm_order();

        }
        else return Redirect::back()
            ->withErrors('Username or Password is incorrect');
    }
    public function order_register(Request $request)
    {
        if (count(User::all()->where('username', $request->input('email'))) > 0)
        {
            return "user already exist";
        }

        $u = new User;
        $u->fname = $request->input('fname');
        $u->lname = $request->input('lname');
        $u->username = $request->input('email');
        $u->password = bcrypt($request->input('password'));
        $u->city = $request->input('city');
        $u->country = $request->input('country');
        $u->state = $request->input('state');
        $u->phone = $request->input('phone');
        $u->save();

        $userdata = array(
            'username' => $request->input('email') ,
            'password' => $request->input('password')
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $request->input('email'));
            session()
                ->put('type', 'client');
            return $this->confirm_order();

        }
        return redirect('/login');

    }
    public function order_register_view()
    {
        return view('order_register');
    }
    public function confirm_order()
    {

        if (session()
            ->get('type') == 'client')
        {

            $a = session()->get("order");
            $total_price = session()->get("total_price");

            $content = session()->get("content");
            $description = session()->get("description");
            $photo = session()->get("photo");
            $price = session()->get("price");
            $code = session()->get("code");
            $first_installment = $total_price / 2;

            $order = new order;
            $order->ladb_process = $a["ladb"];
            $order->our_product_name = $a["our_product"];
            $order->his_product_name = $a["product_name"];
            $order->industry = $a["industry"];
            $order->customer_id = session()->get("id");
            $order->c1 = $a["c1"];
            $order->c2 = $a["c2"];
            $order->logo = $a["logo"];
            $order->cash_slip = $a["cash_slip"];
            $order->content = $content;
            $order->description = $description;
            $order->photo = $photo;
            $order->product_price = $price;
            $order->currency = $code;
            $order->total = $total_price;
            $order->base_requirements = $a["base_requirements"];
            $order->status = 2;
            $order->first_installment = $first_installment;
            $order->save();
            //$order["industry"]
            $new_requirements = DB::select("select* from orders order by id desc ");
            $id = $new_requirements[0]->id;
            $req = session()->get("order.additional_requirements[]");
            if (count($req) > 0)
            {
                foreach ($req as $reqs)
                {
                    $tok = strtok($reqs[2], "\n");

                    $tok = strtok($reqs[2], "\n");

                    $skillset = $tok;
                    $array = array_wrap($skillset);

                    while ($tok !== false)
                    {
                        $tok = strtok("\n");

                        if (is_string($tok)) $skillset = $tok;
                        //  $array = array_prepend($array, $skillset);
                        array_push($array, $skillset);

                    }
                    array_pop($array);
                    foreach ($array as $reqsss)
                    {
                        $reqsss = trim(preg_replace('/\s+/', ' ', $reqsss));
                        DB::insert("insert into additional_requirements (order_id,requirment_for,header,additional_requirements,created_at) values (?,?,?,?,?)", array(
                            $id,
                            $reqs[0],
                            $reqs[1],
                            $reqsss,
                            NOW()
                        ));
                    }

                }

            }
            return redirect('thankyou');
        }
        else
        {
            return redirect('order/process/login');
        }
    }
    public function dashboard()
    {
        $c_id = session()->get('id');
        // return $c_id;
        $order = order::all()->where('customer_id', $c_id)->where('status', '1');
        return view('client.dashboard', compact('order'));
    }

    public function subscribe()
    {
        return view('client.theme_list');
    }

    public function theme_detail()
    {
        return view('client.theme_detail');
    }

    public function payments_detail()
    {
        return view('client.payments_detail');
    }

    public function product_detail_view($id)
    {

        $date = date('Y-m-d');

        $order = order::find($id);

        $tdate = $order
            ->created_at
            ->format('Y-m-d');

        $datetime1 = new DateTime($tdate);
        $datetime2 = new DateTime($order->expected_delivery);

        $interval = $datetime1->diff($datetime2);
        $tdays = $interval->format('%a');

        //  return $tdays;
        $datetime1 = new DateTime($date);
        $datetime2 = new DateTime($order->expected_delivery);
        $interval = $datetime1->diff($datetime2);

        $days = $interval->format('%a');
        //return $days;
        $cdays = $tdays - $days;
        //return $cdays;
        if ($tdays == 0)
        {
            $p = 0;
        }
        else
        {
            $p = ($cdays / $tdays) * 100;
        }

        if ($tdays == 0)
        {
            $e = 0;
        }
        else
        {
            $e = ceil(($days / $tdays) * 100);
        }
        //$e = ($days);
        

        return view('client.product_detail_view', compact('order', 'days', 'p', 'e', 'tdays', 'datetime1', 'datetime2'));
    }

    public function product_requirement_view($id)
    {

        $tabs = DB::select("select requirment_for from additional_requirements where order_id = '$id' and status = 0");
        $new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='Web' ");
        $pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='Web'");
        $approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='Web'");
        $pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='Web'");
        $complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='Web'");

        $Android_new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='Android'");
        $Android_pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='Android' ");
        $Android_approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='Android'");
        $Android_pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='Android'");
        $Android_complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='Android'");

        $IOS_new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 and requirment_for='IOS'");
        $IOS_pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1 and requirment_for='IOS' ");
        $IOS_approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2 and requirment_for='IOS'");
        $IOS_pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3 and requirment_for='IOS'");
        $IOS_complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4 and requirment_for='IOS'");

        $date = date('Y-m-d');

        $order = order::find($id);

        $tdate = $order
            ->created_at
            ->format('Y-m-d');

        $datetime1 = new DateTime($tdate);
        $datetime2 = new DateTime($order->expected_delivery);

        $interval = $datetime1->diff($datetime2);
        $tdays = $interval->format('%a');

        //  return $tdays;
        $datetime1 = new DateTime($date);
        $datetime2 = new DateTime($order->expected_delivery);
        $interval = $datetime1->diff($datetime2);

        $days = $interval->format('%a');
        //return $days;
        $cdays = $tdays - $days;
        //return $cdays;
        

        if ($tdays == 0)
        {
            $p = 0;
        }
        else
        {
            $p = ($cdays / $tdays) * 100;
        }

        if ($tdays == 0)
        {
            $e = 0;
        }
        else
        {
            $e = ceil(($days / $tdays) * 100);
        }
        /*
        
                      $str = $order->additional_requirements;
                      
        $new = "";
          $pending = ""; 
          $approve = "";
          
             $tok = strtok($str, "\n");
           
          if($tok[0] == '*')
          {
        $pending =$tok;
        $array1 = array_wrap($pending);
          }
          else
          {
              $new =$tok;
        $array2 = array_wrap($new);
          }
        $array1 = array_wrap($pending);
        $array2 = array_wrap($new);
        
        while ($tok !== false) {
        $tok = strtok("\n");
        
        if(is_string($tok))
        {
            if($tok[0] == '*')
          {
              $pending =$tok;
        
        array_push($array1, $pending);
             //  $skillset= $tok;
          }
          else{
               $new =$tok;
        array_push($array2, $new);
              
          }
        
        }
        
        
        }
        
        
        */

        return view('client.product_requirement_view', compact('tabs', 'order', 'days', 'p', 'e', 'id', 'tdays', 'datetime1', 'datetime2', 'new_requirements', 'IOS_new_requirements', 'Android_new_requirements', 'pending_requirements', 'IOS_pending_requirements', 'Android_pending_requirements', 'approved_requirements', 'IOS_approved_requirements', 'Android_approved_requirements', 'pcomplete_requirements', 'IOS_pcomplete_requirements', 'Android_pcomplete_requirements', 'complete_requirements', 'IOS_complete_requirements', 'Android_complete_requirements'));

    }

    public function product_payments_view($id)
    {

        $new_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 0 ");
        $pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1");

        $approved_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 2");
        $additional_requirements = DB::select("select* from additional_requirements where order_id = '$id'");
        $pcomplete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 3");
        $complete_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 4");

        $order = order::find($id);

        $a = $order->first_installment;
        $b = $order->total;
        $c = $b - $a;

        return view('client.payment_detail', compact('c', 'a', 'b', 'order', 'new_requirements', 'pending_requirements', 'id', 'approved_requirements', 'pcomplete_requirements', 'complete_requirements', 'additional_requirements'));

    }

    public function pending_to_approved_requirements($id)
    {

        $pending_requirements = DB::select("select* from additional_requirements where order_id = '$id' and status = 1");
        $charges = DB::select("select* from orders where id = '$id'");
        $a = $charges[0]->total;
        $b = $pending_requirements[0]->charges;
        $c = $a + $b;
        DB::update("update orders set total ='$c' where id='$id'");

        foreach ($pending_requirements as $req)
        {
            $p_requirements = $req->days;
        }

        $status = 2;
        //   DB::update("update additional_requirements set status ='$status' where order_id='$id' and status = 1 ");
        DB::update(DB::raw("update additional_requirements set status ='$status'  WHERE order_id = :value AND status = :value1 ") , array(
            'value' => $id,
            'value1' => 1,
        ));

        DB::update("update orders set expected_delivery ='$p_requirements' where id='$id' ");

        return redirect()->back();
        //  return view('client.order_active_detail_page',compact('order'));
        
    }
    public function pending_to_new_requirements($id)
    {
        $status = 0;
        //   DB::update("update additional_requirements set status ='$status' where order_id='$id' and status = 1 ");
        DB::update(DB::raw("update additional_requirements set status ='$status' WHERE order_id = :value AND status = :value1 ") , array(
            'value' => $id,
            'value1' => 1,
        ));

        return redirect()->back();
        //  return view('client.order_active_detail_page',compact('order'));
        
    }
    public function pcomplete_to_complete_requirements($id, Request $request)
    {

        $note = $request->input('note');

        if (empty($note))
        {

            $status = 4;
            $content2 = $request->input('content2');

            foreach ($content2 as $req)
            {

                //    DB::update("update additional_requirements set status ='$status' where order_id='$id' and additional_requirements='$req' ");
                DB::update(DB::raw("update additional_requirements set status ='$status'  WHERE order_id = :value AND additional_requirements = :value1 ") , array(
                    'value' => $id,
                    'value1' => $req,
                ));

            }
        }
        else
        {

            $status = 2;
            $content2 = $request->input('content2');

            foreach ($content2 as $req)
            {

                DB::update(DB::raw("update additional_requirements set status ='$status',  note = '$note' WHERE order_id = :value AND additional_requirements = :value1 ") , array(
                    'value' => $id,
                    'value1' => $req,
                ));

                //   DB::update("update additional_requirements set status ='$status', note = '$note' where order_id='$id' and additional_requirements='$req' ");
                
            }
        }

        return redirect()->back();
        //  return view('client.order_active_detail_page',compact('order'));
        
    }
    public function order_active_product_detail($id)
    {

        $order = order::find($id);

        return view('client.order_active_detail_page', compact('order'));

    }
    public function product_reporting_view($id)
    {
        $ui = order_ui_report::all()->where('order_id', $id);
        $web = order_web_report::all()->where('order_id', $id);
        $and = order_android_report::all()->where('order_id', $id);
        $ios = order_ios_report::all()->where('order_id', $id);

        return view('client.order_reporting', compact('id', 'ui', 'web', 'and', 'ios'));
    }

    public function due_product_view()
    {
        $c_id = Auth::user()->id;
        $order = order::all()->where('customer_id', $c_id)->where('status', '6');
        return view('client.product_due_payment', compact('order'));
    }

    public function completed_product_view()
    {
        $c_id = Auth::user()->id;
        $order = order::all()->where('customer_id', $c_id)->where('status', '3');
        return view('client.product_completed', compact('order'));
    }

    public function refunded_product_view()
    {
        $c_id = Auth::user()->id;
        $order = order::all()->where('customer_id', $c_id)->where('status', '5');
        return view('client.product_refunded', compact('order'));
    }

    public function cancelled_product_view()
    {
        $c_id = Auth::user()->id;
        $order = order::all()->where('customer_id', $c_id)->where('status', '4');
        return view('client.product_cancelled', compact('order'));
    }

    public function add_additional_requirements(Request $request, $id)
    {

        //              $str = $request->input('mytexttt');
        //          $total=0;
        //           if(count($str)>0)
        //           {
        //               $total = count($str);
        //           for($i = 0; $i< $total ; $i = $i+2)
        //           {
        //                 $tok = strtok($str[$i+1], "\n");
        //     $skillset =$tok;
        //   $array = array_wrap($skillset);
        //     while ($tok !== false) {
        //         $tok = strtok("\n");
        //       if(is_string($tok))
        //       $skillset= $tok;
        //      //  $array = array_prepend($array, $skillset);
        //      array_push($array, $skillset);
        //     }
        //   array_pop($array);
        //  foreach($array as $req)
        //  {
        //      $req = trim(preg_replace('/\s+/', ' ', $req));
        //              DB::insert("insert into additional_requirements (order_id,header,additional_requirements,created_at) values (?,?,?,?)",array($id,$str[$i],$req,NOW()));
        //  }
        //      }
        //           }
        $req = $request->input('mytexttt');

        $tok = strtok($req[2], "\n");

        $tok = strtok($req[2], "\n");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok("\n");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }
        array_pop($array);

        foreach ($array as $reqsss)
        {
            $reqsss = trim(preg_replace('/\s+/', ' ', $reqsss));

            DB::insert("insert into additional_requirements (order_id,requirment_for,header,additional_requirements,created_at) values (?,?,?,?,?)", array(
                $id,
                $req[0],
                $req[1],
                $reqsss,
                NOW()
            ));
        }
        return redirect()->back()
            ->with('message', 'You have Successfully added addition requirement, Please wait our Customer Support will review and confirm you by call or email');
    }

    public function add_additional_requirements_view($id)
    {

        $tabs = DB::select("select requirment_for from additional_requirements where order_id = '$id' and status = 0");
        $result = DB::select("select DISTINCT header from additional_requirements where order_id = '$id'");
        return view('client.add_requirements', compact('id', 'result', 'tabs'));
    }

    public function cancelled_order_view()
    {
        $c_id = session()->get("id");
        $order = order::all()->where('customer_id', $c_id)->where('status', '7');
        return view('client.order_cancelled', compact('order'));
    }

    public function active_order_view()
    {
        $c_id = session()->get("id");
        $order = order::all()->where('customer_id', $c_id)->where('status', '2');

        return view('client.order_active', compact('order'));
    }
    public function live_chat_view()
    {
        return view('client.live_chat');
    }

    public function custom_view($id)
    {
        $result = DB::select("select* from custom_links where custom_url = '$id' ");
        $code = $result[0]->currency;
        $ladb = $result[0]->ladb_process;
        $name = $result[0]->product_name;
        $price = $result[0]->price;

        session()
            ->put('product_name', $result[0]->product_name);
        session()
            ->put('ladb_process', $result[0]->ladb_process);
        session()
            ->put('price', $result[0]->price);
        session()
            ->put('currency', $result[0]->currency);

        $product = product::where('ladb_process', $ladb)->where('product_name', $name)->get();

        return view('custom-form2', compact('product', 'code', 'price'));

        //   return view('custom_url1');
        

        
    }

    public function custom_process_2(Request $request)
    {
        session()->put('order.product_name', $request->input('pname'));
        session()
            ->put('order.industry', $request->input('industry'));
        session()
            ->put('order.c1', $request->input('c1'));
        session()
            ->put('order.c2', $request->input('c2'));
        session()
            ->put('order.additional_requirements', '');
        $thumbnail = "";
        if ($request->hasFile('image'))
        {
            $image = $request->file('image');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        session()->put('order.logo', $thumbnail);

        return redirect('/custom/process/step/3');
        //return redirect('/custom/process/step/2');
        
    }

    public function custom_process_2_view(Request $request)
    {

        $ladb = session()->get("ladb_process");
        $name = session()->get("product_name");

        $product = product::where('ladb_process', $ladb)->where('product_name', $name)->get();

        return view('custom-form2', compact('product'));
    }

    public function custom_process_3(Request $request)
    {

        if (session()->has('order.our_product') && session()
            ->get('order.our_product') != $request->input('c'))
        {
            session()
                ->put('edit', 'false');
            session()
                ->put('additional', 'false');

        }
        $p = product::find($request->input('c'));
        if ($request->input('content'))
        {
            $content = $request->input('content');
            session()
                ->put('content', $content);
        }
        if ($request->input('photo'))
        {
            $photo = $request->input('photo');
            session()
                ->put('photo', $photo);
        }
        if ($request->input('description'))
        {
            $description = $request->input('description');
            session()
                ->put('description', $description);
        }

        session()->put('order.our_product', $p->product_name);
        return view('custom_url1');
        //return dd(session()->get('order'));
        //  return redirect('/custom/process/step/3');
        
    }
    public function custom_process_3_view()
    {

        $p = session()->get('order.our_product');
        $description = session()->get('description');
        $content = session()->get('content');
        $photo = session()->get('photo');

        if (!(session()
            ->get('edit') == 'true'))
        {
            $product = product::where('product_name', $p)->get()
                ->first();
            session()
                ->put('order.base_requirements', $product->product_requirements);

            session()
                ->put('order.price', $product->product_price);
            session()
                ->put('order.price_wm', $product->product_price_wm);
            $product = session()->get('order.base_requirements');
            //$result = DB::select("select* from products where product_name = '$p'");
            return view('custom-form3', compact('product'));
        }
        else
        {

            $product = session()->get('order.base_requirements');
            //$result = DB::select("select* from products where product_name = '$p'");
            return view('custom-form3', compact('product'));
        }

    }

    public function custom_cart_view()
    {

        $p = session()->get('price');
        $d = session()->get('description');
        $c = session()->get('content');
        $ph = session()->get('photo');

        $total = $p + $d + $c + $ph;
        $first_installment = $total / 2;
        session()->put('total_price', $total);
        session()->put('first_installment', $first_installment);
        return view('custom_cart_view');
    }

    public function custom_confirm_order()
    {

        if (session()->get('type') == 'client')
        {
            $a = session()->get("order");
            $total_price = session()->get("total_price");
            $content = session()->get("content");
            $description = session()->get("description");
            $photo = session()->get("photo");
            $price = session()->get("price");
            $code = session()->get("currency");

            $first_installment = $total_price / 2;

            $order = new order;
            $order->ladb_process = session()
                ->get('ladb_process');
            $order->our_product_name = $a["our_product"];
            $order->his_product_name = $a["product_name"];
            $order->industry = $a["industry"];
            $order->customer_id = Auth::user()->id;
            $order->c1 = $a["c1"];
            $order->c2 = $a["c2"];
            $order->logo = $a["logo"];
            $order->cash_slip = $a["cash_slip"];
            $order->content = $content;
            $order->description = $description;
            $order->photo = $photo;
            $order->product_price = $price;
            $order->currency = $code;
            $order->total = $total_price;
            $order->first_installment = $first_installment;
            $order->base_requirements = $a["base_requirements"];
            $order->status = 2;
            $order->save();
            //$order["industry"]
            $new_requirements = DB::select("select* from orders order by id desc ");
            $id = $new_requirements[0]->id;
            $str = session()->get("order.additional_requirements");
            $total = 0;
            if (!empty($str))
            {
                if (count($str) > 0)
                {
                    $total = count($str);
                    for ($i = 0;$i < $total;$i = $i + 2)

                    {

                        $tok = strtok($str[$i + 1], "\n");

                        $skillset = $tok;
                        $array = array_wrap($skillset);

                        while ($tok !== false)
                        {
                            $tok = strtok("\n");

                            if (is_string($tok)) $skillset = $tok;
                            //  $array = array_prepend($array, $skillset);
                            array_push($array, $skillset);

                        }
                        array_pop($array);
                        foreach ($array as $req)
                        {
                            $req = trim(preg_replace('/\s+/', ' ', $req));
                            DB::insert("insert into additional_requirements (order_id,header,additional_requirements,created_at) values (?,?,?,?)", array(
                                $id,
                                $str[$i],
                                $req,
                                NOW()
                            ));
                        }
                    }
                }
            }
            return redirect('thankyou');
        }
        else
        {
            return redirect('custom/process/login');
        }
    }

    public function custom_order_login_view()
    {

        return view('custom_order_login_view');

    }
    public function custom_link_order_login(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');
        $userdata = array(
            'username' => $username,
            'password' => $password
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $username);
            session()->put('type', 'client');

            return $this->custom_confirm_order();

        }
        else return Redirect::back()
            ->withErrors('Username or Password is incorrect');
    }

    public function custom_edit_base_requirement_view()
    {
        return view('custom-product-form4');
    }

    public function custom_edit_base_requirement(Request $request)
    {
        $br = $request->input('br');
        session()
            ->put('order.base_requirements', $br);
        session()->put('edit', 'true');
        return redirect('/custom/process/step/3');
    }
    public function custom_add_additional_requirement_view()
    {
        return view('custom-product-form5');
    }

    public function custom_add_additional_requirement(Request $request)
    {

        $str = $request->input('mytexttt');
        session()
            ->put('order.additional_requirements', $str);
        session()->put('additional', 'true');
        return redirect('/custom/process/step/3');
    }

    public function order_register_custom_view()
    {
        return view('order_register_custom');
    }

    public function order_register_custom(Request $request)
    {
        if (count(User::all()->where('username', $request->input('email'))) > 0)
        {
            return "user already exist";
        }

        $u = new User;
        $u->fname = $request->input('fname');
        $u->lname = $request->input('lname');
        $u->username = $request->input('email');
        $u->password = bcrypt($request->input('password'));
        $u->city = $request->input('city');
        $u->country = $request->input('country');
        $u->state = $request->input('state');
        $u->phone = $request->input('phone');
        $u->save();

        $userdata = array(
            'username' => $request->input('email') ,
            'password' => $request->input('password')
        );

        if (Auth::attempt($userdata))
        {
            session()->put('username', $request->input('email'));
            session()
                ->put('type', 'client');
            return $this->custom_confirm_order();

        }
        return redirect('/login');

    }

    public function wordpress_view()
    {
        return view('wordpress');
    }
    public function addition_wordpress_view()
    {

        return view('additional_wordpress');

    }

    public function wordpress_order_login_view()
    {
        return view('wordpress_login');
    }

    public function addToCart(Request $request)
    {
        $price = '97';
        $content = '0';
        $a_pages = '0';
        $banner = '0';
        $woocommerce = '0';
        $payment = '0';

        session()->put('price', $price);

        if ($request->input('content'))
        {
            $content = $request->input('content');
            session()
                ->put('content', $content);
        }

        if ($request->input('a_pages'))
        {
            $a_pages = $request->input('a_pages');
            session()
                ->put('a_pages', $a_pages);
        }

        if ($request->input('banner'))
        {
            $banner = $request->input('banner');
            session()
                ->put('banner', $banner);
        }

        if ($request->input('woocommerce'))
        {
            $woocommerce = $request->input('woocommerce');
            session()
                ->put('woocommerce', $woocommerce);
        }

        if ($request->input('payment'))
        {
            $payment = $request->input('payment');
            session()
                ->put('payment', $payment);
        }
        $sum = $price + session()->get('a_pages') + session()
            ->get('content') + session()
            ->get('woocommerce') + session()
            ->get('payment') + session()
            ->get('banner');
        // $count = [$price] + [session()->get('a_pages')] + [$content] + [session()->get('woocommerce')] + [session()->get('payment') ] + [session()->get('banner')];
        // return collect($count)->count();
        session()
            ->put('sum', $sum);

        // return session()->get('sum');
        

        return view('wordpress_cart', compact('sum'));

    }

    public function wordpress_order_cart()
    {
        $id = session()->get('id');
        $price = session()->get('price');
        $banner = session()->get('banner');
        $content = session()->get('content');
        $payment = session()->get('payment');
        $sum = session()->get('sum');
        $woocommerce = session()->get('woocommerce');
        $a_pages = session()->get('a_pages');
        return view('wordpress_cart', compact('sum'));
    }

    public function remove_order()
    {
        session()
            ->forget('price');
        session()
            ->forget('woocommerce');
        session()
            ->forget('payment');
        session()
            ->forget('banner');
        session()
            ->forget('a_pages');
        session()
            ->forget('content');
        session()
            ->forget('sum');
        session()
            ->forget('slip');
        return view('wordpress');
    }

    public function wordpress_confirm_order()
    {
        if (session()
            ->get('type') == 'client')
        {
            $id = session()->get('id');
            $price = session()->get('price');
            $banner = session()->get('banner');
            $content = session()->get('content');
            $payment = session()->get('payment');
            $sum = session()->get('sum');
            $woocommerce = session()->get('woocommerce');
            $a_pages = session()->get('a_pages');

            $thumbnails = session()->get('slip');

            $status = '0';
            $start_date = '0';
            $deliverydate = '0';
            DB::insert("insert into  wordpress_order (c_id,price,sum,content,banner,a_pages,woocommerce,payment,status,thumbnail,order_date,start_date,deliverydate) values (?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $id,
                $price,
                $sum,
                $content,
                $banner,
                $a_pages,
                $woocommerce,
                $payment,
                $status,
                $thumbnails,
                NOW() ,
                $start_date,
                $deliverydate
            ));

            session()->forget('price');
            session()
                ->forget('woocommerce');
            session()
                ->forget('payment');
            session()
                ->forget('banner');
            session()
                ->forget('a_pages');
            session()
                ->forget('content');
            session()
                ->forget('sum');

            session()
                ->forget('slip');
            return redirect('thankyou');
        }
        else
        {
            return view('wordpress_signup');
        }
    }

    public function paywithpaypal()

    {
        $id = session()->get('id');
        $price = session()->get('price');
        $banner = session()->get('banner');
        $content = session()->get('content');
        $payment = session()->get('payment');
        $sum = session()->get('sum');
        $woocommerce = session()->get('woocommerce');
        $a_pages = session()->get('a_pages');
        $paypal = "paypal";
        session()->put('paypal', $paypal);
        if (session()->get('type') == 'client')
        {
            return view('paypal_view', compact('id', 'price', 'banner', 'content', 'payment', 'sum', 'woocommerce', 'a_pages'));

        }
        else
        {
            return view('wordpress_signup');

        }

    }

    public function wordpress_order_signup(Request $request)
    {
        // return "helo";
        if ($request->input('password') == $request->input('cpassword'))
        {
            $username = $request->input('email');
            $result = DB::select("select* from users where username = '$username' ");
            if (count($result) > 0)
            {
                return Redirect::back()->withErrors('Username already Exist');
            }
            else
            {

                $password = $request->input('password');
                DB::insert("insert into users (fname,lname, username, password,city,country,state,phone ) values (?,?,?,?,?,?,?,?)", array(
                    $request->input('fname') ,
                    $request->input('lname') ,
                    $request->input('email') ,
                    md5($password) ,
                    $request->input('city') ,
                    $request->input('country') ,
                    $request->input('state') ,
                    $request->input('phone')
                ));
                $this->validate($request, ['email' => 'required', 'password' => 'required']);
                $username = $request->input('email');
                $password = md5($request->input('password'));
                $result = DB::select("select* from users where username = '$username' and password='$password' ");
                if (count($result) > 0)
                {
                    $request->session()
                        ->put('id', $result[0]->{'id'});
                    $request->session()
                        ->put('username', $username);
                    $request->session()
                        ->put('type', 'client');
                    $request->session()
                        ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                    $request->session()
                        ->put('fname', $result[0]->{'fname'});
                    $request->session()
                        ->put('lname', $result[0]->{'lname'});
                    $sum = session()->get('sum');

                    $sum = session()->get('sum');

                    $paypal = session()->get('paypal');

                    if ($paypal == "paypal")
                    {
                        $id = session()->get('id');
                        $price = session()->get('price');
                        $banner = session()->get('banner');
                        $content = session()->get('content');
                        $payment = session()->get('payment');
                        $sum = session()->get('sum');
                        $woocommerce = session()->get('woocommerce');
                        $a_pages = session()->get('a_pages');

                        return view('paypal_view', compact('id', 'price', 'banner', 'content', 'payment', 'sum', 'woocommerce', 'a_pages'));

                    }
                    else
                    {
                        return $this->wordpress_confirm_order();
                    }
                }
            }
        }
        else
        {
            return Redirect::back()
                ->withErrors('Password does not match');
        }

    }

    public function wordpress_order_login(Request $request)
    {
        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $username = $request->input('username');
        $password = md5($request->input('password'));
        $result = DB::select("select* from users where username = '$username' and password='$password' ");

        if (count($result) > 0)
        {
            $request->session()
                ->put('id', $result[0]->{'id'});
            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('type', 'client');
            $request->session()
                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
            $request->session()
                ->put('fname', $result[0]->{'fname'});
            $request->session()
                ->put('lname', $result[0]->{'lname'});
            $sum = session()->get('sum');

            $paypal = session()->get('paypal');

            if ($paypal == "paypal")
            {
                $id = session()->get('id');
                $price = session()->get('price');
                $banner = session()->get('banner');
                $content = session()->get('content');
                $payment = session()->get('payment');
                $sum = session()->get('sum');
                $woocommerce = session()->get('woocommerce');
                $a_pages = session()->get('a_pages');

                return view('paypal_view', compact('id', 'price', 'banner', 'content', 'payment', 'sum', 'woocommerce', 'a_pages'));

            }
            else
            {
                return $this->wordpress_confirm_order();
            }

        }
        else
        {
            return Redirect::back()
                ->withErrors('Username or Password is incorrect');
        }
    }

    public function slip_upload(Request $request)
    {

        $thumbnails = "";
        if ($request->hasFile('slip'))
        {
            $image = $request->file('slip');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnails = $uniqueFileName;
        }
        session()->put('slip', $thumbnails);

        if (session()->get('type') == 'client')
        {
            return $this->wordpress_confirm_order();
        }
        else
        {
            return view('wordpress_signup');

        }

    }
    public function wordpress_active_order()
    {
        $id = session()->get('id');
        $result = DB::select("select* from wordpress_order where c_id = '$id'");
        return view('client.wordpress_order_list', compact('result'));

    }

    public function update_wordpress_order($id)
    {
        if (session()->get('type') == 'client')
        {
            $result = DB::select("select* from wordpress_order where pk_id = '$id'");
            $sum = $result[0]->sum;
            return view('client.wordpress_order_update', compact('result', 'sum', 'id'));
        }
        else
        {
            return view('wordpress_login');
        }

    }

    public function updateToCart(Request $request, $id)
    {
        $result = DB::select("select* from wordpress_order where pk_id = '$id'");
        $sum = $result[0]->sum;
        $price = $result[0]->price;
        $oldcontent = $result[0]->content;
        $olda_pages = $result[0]->a_pages;
        $oldbanner = $result[0]->banner;
        $oldwoocommerce = $result[0]->woocommerce;
        $oldpayment = $result[0]->payment;

        if ($request->input('content'))
        {
            $newcontent = $request->input('content');

            $content = $request->input('content') + $oldcontent;
            session()->put('content', $content);
        }

        if ($request->input('a_pages'))
        {
            $newa_pages = $request->input('a_pages');

            $a_pages = $request->input('a_pages') + $olda_pages;
            session()->put('a_pages', $a_pages);
        }
        if ($request->input('banner'))
        {
            $newbanner = $request->input('banner');
            $banner = $request->input('banner') + $oldbanner;
            session()->put('banner', $banner);
        }

        if ($request->input('woocommerce'))
        {

            $newwoocommerce = $request->input('woocommerce');
            $woocommerce = $request->input('woocommerce') + $oldwoocommerce;
            session()->put('woocommerce', $woocommerce);
        }

        if ($request->input('payment'))
        {
            $newpayment = $request->input('payment');
            $payment = $request->input('payment') + $oldpayment;
            session()->put('payment', $payment);
        }
        $newcontent = $request->input('content');
        $newwoocommerce = $request->input('woocommerce');
        $newpayment = $request->input('payment');
        $newa_pages = $request->input('a_pages');
        $newbanner = $request->input('banner');
        $update = $newa_pages + $newcontent + $newwoocommerce + $newpayment + $newbanner;

        $sum = $sum + $newa_pages + $newcontent + $newwoocommerce + $newpayment + $newbanner;
        session()->put('sum', $sum);
        return view('client.update_cart', compact('sum', 'id', 'update', 'newcontent', 'newwoocommerce', 'newpayment', 'newa_pages', 'newbanner'));
    }

    public function updateorder(Request $request, $id)
    {
        $banner = session()->get('banner');
        $content = session()->get('content');
        $payment = session()->get('payment');
        $sum = session()->get('sum');
        $woocommerce = session()->get('woocommerce');
        $a_pages = session()->get('a_pages');
        $thumbnails = "";
        if ($request->hasFile('slip'))
        {
            $image = $request->file('slip');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnails = $uniqueFileName;
        }
        $status = '0';
        $start_date = '0';
        $deliverydate = '0';

        if (!empty(session()->get('content')))
        {

            DB::update("update wordpress_order set sum ='$sum', content = '$content',status='$status',start_date='$start_date',deliverydate='$deliverydate',order_date= now(),thumbnail = '$thumbnails' where pk_id='$id'");
        }

        if (!empty(session()->get('a_pages')))
        {
            DB::update("update wordpress_order set sum ='$sum', a_pages = '$a_pages',status='$status',start_date='$start_date',deliverydate='$deliverydate',order_date= now(),thumbnail = '$thumbnails' where pk_id='$id'");

        }
        if (!empty(session()->get('banner')))
        {
            DB::update("update wordpress_order set sum ='$sum', banner = '$banner',status='$status',start_date='$start_date',deliverydate='$deliverydate',order_date= now(),thumbnail = '$thumbnails' where pk_id='$id'");

        }
        if (!empty(session()->get('woocommerce')))
        {
            DB::update("update wordpress_order set sum ='$sum', woocommerce = '$woocommerce',status='$status',start_date='$start_date',deliverydate='$deliverydate',order_date= now(),thumbnail = '$thumbnails' where pk_id='$id'");

        }
        if (!empty(session()->get('payment')))
        {
            DB::update("update wordpress_order set sum ='$sum', payment = '$payment',status='$status',start_date='$start_date',deliverydate='$deliverydate',order_date= now(),thumbnail = '$thumbnails' where pk_id='$id'");

        }
        session()->forget('woocommerce');
        session()
            ->forget('payment');
        session()
            ->forget('banner');
        session()
            ->forget('a_pages');
        session()
            ->forget('content');
        session()
            ->forget('sum');
        return redirect('wordpress/active/order');

    }

    public function view_wordpress_order($id)
    {
        $result = DB::select("select* from wordpress_order where pk_id = '$id'");
        return view('client.wordpress_order_view', compact('result'));

    }

    //================================= ECOM ORDERS =================================//
    

    public function portfolio_detail()
    {

        return view('portfolio_detail');

    }
    public function ecom_order_login_view()
    {
        return view('ecom_login');
    }

    public function ecom_order_login(Request $request)
    {

        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $username = $request->input('username');
        $password = md5($request->input('password'));
        $result = DB::select("select* from users where username = '$username' and password='$password' ");
        // return $result;
        if (count($result) > 0)
        {
            $request->session()
                ->put('id', $result[0]->{'id'});
            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('type', 'client');
            $request->session()
                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
            $request->session()
                ->put('fname', $result[0]->{'fname'});
            $request->session()
                ->put('lname', $result[0]->{'lname'});
            return $this->create_ecom_order2();
        }
        else
        {
            // return "sddasd";
            return view('ecom_login')
                ->withErrors('Username or Password is incorrect');
        }
    }

    public function create_ecom_order(Request $request)
    {

        // return $current;
        $theme = $request->input('theme');
        session()
            ->put('theme', $theme);
        $pkj = $request->input('pkj');
        session()
            ->put('pkj', $pkj);
        $thumbnails = "";
        if ($request->hasFile('slip'))
        {
            $image = $request->file('slip');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnails = $uniqueFileName;
        }
        session()->put('slip', $thumbnails);

        //  $theme = session()->get('theme');
        //  return "jjjj";
        if (session()->get('type') == 'client')
        {

            return $this->create_ecom_order2();

        }
        else
        {
            return view('ecom_login');
        }

    }

    public function create_ecom_order2()
    {
        $current = Carbon::now();
        // return $current;
        $name = Session::get('fname');

        $email = session()->get('username');
        $theme = session()->get('theme');
        $pkj = session()->get('pkj');
        $thumbnails = session()->get('slip');
        // return $thumbnails;
        

        if ($pkj == "14999")
        {
            $package = "1 Month";

            $end_date = $current->addDays(30);
        }
        elseif ($pkj == "42750")
        {
            $package = "3 Month";
            $end_date = $current->addDays(90);
        }
        elseif ($pkj == "81000")
        {
            $package = "6 Month";
            $end_date = $current->addDays(180);
        }
        elseif ($pkj == "144000")
        {
            $package = "1 Year";
            $end_date = $current->addMonth(365);
        }
        else
        {
            $package = "0";
            $end_date = "0";
        }

        //   DB::insert("insert into ecom_order (username,verification_code) values('$username','$vcode') ");
        DB::insert("insert into ecom_order (name,email,theme,price,package,end_date,slip) values (?,?,?,?,?,?,?)", array(
            $name,
            $email,
            $theme,
            $pkj,
            $package,
            $end_date,
            $thumbnails
        ));
        session()->forget('theme');
        session()
            ->forget('pkj');
        session()
            ->forget('slip');
        return redirect('thankyou');

    }

    public function ecom_active_order()
    {
        $username = session()->get('username');
        $result = DB::select("select* from ecom_order where email = '$username'");
        return view('client.ecom_order_view', compact('result'));

    }

}

