<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class order_android_report extends Model
{
    //
}
