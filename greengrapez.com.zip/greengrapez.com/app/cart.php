<?php

namespace App;
use Session;

use Illuminate\Database\Eloquent\Model;

class cart extends Model
{
    
    public $price =  '97';
    public $content = '0';
    public $a_pages = '0';
    public $banner = '0';
    public $woocommerce = '0';
    public $payment ='0';
   
    public function __construct($oldCart)
    {
        if($oldCart)
        {
            
            $this->price = $oldCart->price;
            $this->content = $oldCart->content;
            $this->a_pages = $oldCart->a_pages;
            $this->banner = $oldCart->banner;
            $this->woocommerce = $oldCart->woocommerce;
            $this->payment = $oldCart->payment;
        }
    }
    public function add($price,$content,$a_pages,$banner,$woocommerce, $payment)
    {
        
        $storedItem = ['qty'=>$q,'price'=>$item->price,'save'=>0,'item'=>$item,'size'=>$size];
        $id = $id.$size;
        if($this->items)
        {
           
            if(array_key_exists($id,$this->items))
            {
                     //   $this->totalQty -= $this->items[$id]['qty'];
                     $this->totalQty--;
        $this->totalPrice -= $this->items[$id]['price'];
        unset($this->items[$id]);
      //   $this->totalQty++;
                $storedItem['price'] = $item->price * $storedItem['qty'];
             //   $storedItem= $this->items[$id];
            }
        }
        
        
       
       // $storedItem['qty']++;
        $storedItem['price'] = $item->price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty++;
        $this->abc += $storedItem['qty'];
        
        $this->totalPrice += $storedItem['price'];

      
       
    }
 


}
