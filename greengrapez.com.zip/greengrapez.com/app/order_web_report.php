<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class order_web_report extends Model
{
    //
}
