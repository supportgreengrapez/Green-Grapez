<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Mail;
use Response;
class everyminute extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'status:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //
        // $email = DB::select("select DISTINCT users.username from task,users where users.id= task.customer_id  and  week(task.updated_at)=week(now())");
        
        // $task = DB::select("select project_name,task,status,updated_at from task where status = '1' and week(updated_at)=week(now())");
        
        // $name ="Green Grapez";
        
        // $data = array(
        //         'task' => $task,
        //         'name' => $name,
        //     );
            
        //      Mail::send('task_complete', $data, function ($message) use ($name)
        //   {
        //       $message->from('info@general.greengrapez.com', 'Green Grapez');
        //       $message->to('support@greengrapez.com')->subject('Task Complete Email');
        //   });
    }
}
