<?php
namespace App\Http\Controllers;
use Redirect;
use Illuminate\Http\Request;
use Auth;
use DB;
use Table;
use App\product;
use App\order;
use App\order_ui_report;
use App\order_ios_report;
use App\order_android_report;
use App\order_web_report;
use App\User;
use App\developer;
use App\project_assignment;
use App\task;
use App\tasklist;
use Hash;
class developerController extends Controller
{
    public function login_view()
    {
        return view('developer.login');
    }

    public function login(Request $request)
    {
       
        $username = $request->input('username');
        $password = $request->input('password');
        if(count(developer::where('email',$username)->get())>0)
        {

        
       
        $userdata = array(
            'email'     => $username,
            'password'  => $password
        );
        $u =  developer::where('email',$username)->first();
        if(Hash::check($password,$u->password))
        {
            
            session()->put('username',$username);
            session()->put('type','developer');
        
            
            $u =  developer::where('email',$username)->first();
           
            session()->put('id',$u->id);
            session()->put('name',$u->fname.' '.$u->lname);
            
           
           return redirect('developer-dashboard');
        }
        else
        return redirect('/developer')->with('error','Username or Password is incorrect');
    }
    else
    return redirect('/developer')->with('error','Username or Password is incorrect');
    }
    public function dashboard()
    {
       $t=[];
       $id = session('id');
       $t= db::select("select tasklists.task_id as tid,tasks.*,tasklists.* from tasks,tasklists where developer_id = '$id' and tasklists.task_id = tasks.id and tasklists.status='pending' group by tasklists.id");
        return view('developer.dashboard',compact('t'));
    }
    
    public static function getProjectNameByTask($project_id)
    {
        $t = db::select("select* from orders where id = '$project_id'");
        return $t[0]->{'his_product_name'};
    }

    public function assigned_project_list()
    {
        $id = session('id');
        $a = db::select("select project_assignments.id as tid,project_assignments.project_id as pid,orders.his_product_name as pname from orders,project_assignments where project_assignments.developer_id = '$id' and project_assignments.project_id = orders.id");
        return view('developer.view_assigned_projects',compact('a'));
    }

    public function task_list($project_id)
    { 
        $developer_id = session('id');
        $t = task::where('project_id',$project_id)->where('developer_id',$developer_id)->get();
  return view('developer.project_task_list',compact('t'));
    }

    public function tasks_task_list($id)
    {
        $t = tasklist::where('task_id',$id)->get();

        return view('developer.tasks_task_list_view',compact('t','id'));
    }

    public function mark_a_task_complete($id,$rtid)
    {
       $t =  tasklist::find($id);
       $t->status= "completed";
       $t->save();

       return redirect('/developer-project-view-task-tasks-list/'.$rtid)->with('message','Your task successfully mark completed');
    }
    public function logout()
    {
        session()->flush();
        return redirect('/developer');
    }
}
