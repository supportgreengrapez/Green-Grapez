<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tasklist extends Model
{
    //
}
